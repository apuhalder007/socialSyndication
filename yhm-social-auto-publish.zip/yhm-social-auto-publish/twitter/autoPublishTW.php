<?php
require_once dirname(__DIR__) . '/vendor/autoload.php'; // change path as needed
require_once dirname(__DIR__) . '/vendor/dg/twitter-php/src/twitter.class.php';


class autoPubTW{
	private $consumerKey;
	private $consumerSecret; 
	private $accessToken;
	private $accessTokenSecret;
	private $twitterCon;

	function __construct(){
		$this->consumerKey = "bXy5o1yaPBeHGL9Pyqa4gnmWu";
		$this->consumerSecret = "qOKb6acAi8Oyl3IsSRfrxoFggfXkp2SSk0Xxlhs41qw2Ag8YoQ"; 
		$this->accessToken = "277351343-y3oEQzzFBxkTWH40WQU5nkyRIxF9sV4QdWUH19R1";
		$this->accessTokenSecret = "pbzTKfFEo5riPNCsaTFAFyK69cdETZwWuG0CpKoUczQe6";
		$this->twitter = new Twitter($this->consumerKey, $this->consumerSecret, $this->accessToken, $this->accessTokenSecret);
	}

	function do_publish($data){
		try {
			$title = $this->charecter_limit($data->post_title);
		    $statuses = $this->twitter->send(
				$title  //,  // title
				//['innerlogo.jpg', 'logo1.png', 'pic.jpg'] // media
			);

		    return $statuses;
		} catch (TwitterException $e) {
			return "Error: ". $e->getMessage();
		}
	}

	function charecter_limit($str){
		$tweet_len = 140;
		$str_length = strlen($str);
		$new_str = ($str_length < 1 && $str_length > $tweet_len ) ? 
					substr($str, 0, ($tweet_len - 4)) . '...'
					: $str;

		return $new_str;		
	}
	

}



