<?php 
require_once(dirname(__FILE__).'/cron-class.php');
$cornObj = new autoPublishCorn();
$results = $cornObj->publish_post();
echo '<pre>';
print_r($results);
echo '</pre>';
?>