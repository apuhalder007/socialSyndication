<?php
$absolute_path = dirname(dirname(dirname(__DIR__))).'/';
require_once($absolute_path .'wp-load.php');
require_once(dirname(__FILE__) .'/twitter/autoPublishTW.php');
require_once(dirname(__FILE__) .'/facebook/autoPublishFB.php');
require_once(dirname(__FILE__) .'/linkedin/autoPublishLKD.php');
class autoPublishCorn{
    private $wpdb;
    private $curdate;
    function __construct(){
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->curdate = date('Y-m-d');
    }

    function getCurrentDayScheduleList(){
        $results = [];
        $prefix = $this->wpdb->prefix;

        $sql = "
            SELECT p.ID, p.post_title, p.guid, 
            tschedule.meta_value as tscheduleTime,  fschedule.meta_value as fscheduleTime,
            lschedule.meta_value as lscheduleTime FROM ".$prefix."posts as p
            INNER JOIN ".$prefix."postmeta as tschedule
            ON tschedule.post_id = p.ID

            INNER JOIN ".$prefix."postmeta as fschedule
            ON fschedule.post_id = p.ID
            
            INNER JOIN ".$prefix."postmeta as lschedule
            ON lschedule.post_id = p.ID

            WHERE 1=1
            AND (
                (tschedule.meta_key = 'twitter_scheduleDatetime' AND tschedule.meta_value = '".$this->curdate."')
                OR (fschedule.meta_key = 'facebok_scheduleDatetime' AND fschedule.meta_value = '".$this->curdate."')
                OR ( lschedule.meta_key = 'linkedin_scheduleDatetime' AND lschedule.meta_value = '".$this->curdate."')
            )
            AND p.post_type = 'article'

            group by p.ID
        ";

        $results = $this->wpdb->get_results($sql);

        return $results;
        
    }
    function publish_post(){
        $result = [];
        $tw= new autoPubTW();
        $posts = self::getCurrentDayScheduleList();

        if(count($posts) > 0){

            echo '<pre>';
            print_r($posts);
            echo '</pre>';
            foreach($posts as $post){
                if($post->tscheduleTime == $this->curdate){
                    $twitter = new autoPubTW();
                    $result['twitter'] = $twitter->do_publish($post);
                }
                if($post->fscheduleTime == $this->curdate){

                }
                if($post->lscheduleTime == $this->curdate){
                    $linkedin = new AutoPubLKD();
                    $result['linkedin'] = $linkedin->do_publish($post);
                    
                }
            }
        }

        return $result;
        
    }

}
