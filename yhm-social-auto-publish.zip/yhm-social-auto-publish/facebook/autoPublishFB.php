<?php
require_once dirname(__DIR__) . '/vendor/autoload.php'; // change path as needed


class autoPubFB{

  private $fbCon;
  private $app_id;
  private $app_secret;

  /*Get non-expire token
  https://graph.facebook.com/oauth/access_token?grant_type=fb_exchange_token&client_id=321041655068603&client_secret=4d91105120314fec5456c7ac49dfd8a9&fb_exchange_token=EAAERXqDiW9YBANjmitpS0hAZAEkpFQgcxd7qmKI5WYKPPLK95bwZAPmGsZAiSoZAJLmuZCmoJwwKmvOkSFRPGC1XmfuepW3zmWYb6z61it1EhcjQ3uCZC5KCakqDOpca30eAID06FXdZCk5CAXdHvX5BhnvLgUQfKVxa4KTSEci4o7GsPjjuAypmdUJjHumrg0ZD*/

  private $default_access_token;
  private $default_graph_version;

  function __construct(){
    $this->app_id = '321041655068603';
    $this->app_secret = '4d91105120314fec5456c7ac49dfd8a9';
    $this->default_graph_version = 'v2.10';
    $this->default_access_token = 'EAAEjZCFXO97sBAHGbtZCxBQTvP0a92GoO2tp9cQzJab6KR2qAFYPGRI613vbfoqFcWw1PnScLqvao9H2OOsl76Y8MkqRhZBwVEefyLsedGIR8zwrrvpB8KdgBwYXb2O71xgFjTuMD1h9eNBKqgiIrWG8Ox2ZCJwZD';


    $this->fbCon = new \Facebook\Facebook([
      'app_id' => $this->app_id,
      'app_secret' => $this->app_secret,
      'default_graph_version' => $this->default_graph_version,
      'default_access_token' => $this->default_access_token, // optional
    ]);
  }

  function do_publish(){
    //Post property to Facebook
    $linkData = [
     'link' => 'www.yoururl.com',
     'message' => 'Your message here'
    ];

    try {
     $response = $this->fbCon->post('/me/feed', $linkData);

    } catch(Facebook\Exceptions\FacebookResponseException $e) {

     echo 'Graph returned an error: '.$e->getMessage();
     exit;
    } catch(Facebook\Exceptions\FacebookSDKException $e) {

     echo 'Facebook SDK returned an error: '.$e->getMessage();
     exit;
    }
    $graphNode = $response->getGraphNode();
  }
}

