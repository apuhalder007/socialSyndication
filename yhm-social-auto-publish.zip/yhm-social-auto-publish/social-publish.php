<?php 


defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * @package YHM_Social_auto_Publish
 * @version 1.6
 */
/*
Plugin Name: YHM Social Auto Publish
Description: Share Article content to Social Platforms .
Author: KSPL
Version: 1.0.0
*/

require_once(dirname(__FILE__).'/actions.php');
require_once(dirname(__FILE__).'/metabox/articleSocialMetabox.php');

class SocialAutoPublishArticle{
    function __construct(){
       define( 'YHM_SOCIAL_PATH', plugin_dir_path( __FILE__ ) );
       $this->loadResources();
       
    }

    function loadResources(){
       $action_obj = new socialMediaPublishActions();
       $action_obj->init_action();
       $metaBoxObj = new yhmArticleSocial_Meta_Box();
       $metaBoxObj->load_meta_hooks();
    }

     function yhm_add_rewrite_rule() {
	    
		add_rewrite_tag( '%yhm_auto_publish%', '([^&]+)' );
	    
	    add_rewrite_rule(
	        '^auto-publish-corn/?',
	        'index.php?yhm_auto_publish=publish_on_social_platform',
	        'top'
		);
		
	    flush_rewrite_rules();
	}

		
	function yhm_rewrite_catch() {
	    global $wp_query;
	    if ( array_key_exists( 'yhm_auto_publish', $wp_query->query_vars ) ) {
	    	require_once ( dirname( __FILE__ ) . '/auto_publish_corn.php');
            die(); // stop default WP behavior

		}

	}
}

add_action('admin_init', 'load_social_plugin');
function load_social_plugin(){
    new SocialAutoPublishArticle();
}

add_action('init', ['SocialAutoPublishArticle','yhm_add_rewrite_rule']);
add_action('template_redirect', ['SocialAutoPublishArticle','yhm_rewrite_catch']);

?>