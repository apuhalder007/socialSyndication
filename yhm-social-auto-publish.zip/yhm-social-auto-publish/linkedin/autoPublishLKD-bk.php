<?php
require_once dirname(__DIR__) . '/vendor/autoload.php';
use \Http\Adapter\Guzzle6\Client;
class AutoPubLKD{

	private $app_id ;
	private $app_secret;
	private $linkedInCon;
	private $visibility;
	//access token genarate link
	//https://stackoverflow.com/questions/27720081/how-is-obtaining-the-access-token-in-linkedin-oauth-2-0-authentication-supposed
	private $access_token;

	function __construct(){
		$this->access_token = "AQWy-jI9EaGyw-umCXoCnJcx1dVSD7EcpUFGe3IP7bcFqWGfHQaOoOwzWSBdRGFDpkYLhRk2aePST1K15e7dQyQnu4krVC4ywQHuvXf_XZyM-zN00BwQH9w590kMrGQBt6UIqivC_CajREEa6apfcfgRrhc5edbbjmQBZpR8HDvTPe4CHW5wwH1TjtQRsxE4Nzj1_ybo-ob0P0RxTvLVpEnUwj1ku6I1bJGMZ8BOIaOjentDz-bqQmfaRnkVQjdtRyDQWpDY1VJ-3b7qJ8tO0kDsO61ZsfmatIAPEODZnk8B7m4e8D4ve5oPciVqvprhUNKLFMw-TgnkCSPIBNScE_6B_FqHZA";

	    $this->app_id = "81wx4px7cakwe0";
	    $this->app_secret = "O0dRjwNQXknoWxEy";
	    $this->visibility = 'anyone';

		$this->linkedInCon = new Happyr\LinkedIn\LinkedIn($this->app_id, $this->app_secret);
		$this->linkedInCon->setHttpClient(new Client());
		$this->linkedInCon->setHttpMessageFactory(new Http\Message\MessageFactory\GuzzleMessageFactory());

	}

	function format_data($postData = null){
		if($postData == null) return ;

		
	}

	function do_publish($data){

		/**
		 * This demonstrates how to authenticate with LinkedIn and send api requests
		 */

		/*
		 * First you need to make sure you've used composers auto load. You have is probably 
		 * already done this before. You usually don't bother..
		 */
		//require_once "vendor/autoload.php";

		$this->linkedInCon->setAccessToken($this->access_token);

		$titleWithLink = '';
		$titleWithLink .= $data->post_title;
		$titleWithLink .= " ";
		$titleWithLink .= $data->guid;

		//https://github.com/Happyr/LinkedIn-API-client
		$options = array('json'=>
		    array(
		        'comment' => 'Im testing Happyr LinkedIn client! https://github.com/Happyr/LinkedIn-API-client',
		        'visibility' => array(
		            'code' => $this->visibility
		        )
		    )
		);

		$result = $this->linkedInCon->post('v1/people/~/shares', $options);
		//var_dump($result);
		return $titleWithLink;
	}


}