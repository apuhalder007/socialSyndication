<?php 
require_once(dirname(__FILE__).'/facebook/autoPublishFB.php');
require_once(dirname(__FILE__).'/twitter/autoPublishTW.php');
require_once(dirname(__FILE__).'/linkedin/autoPublishLKD.php');
class socialMediaPublishActions{

    function __construct(){
        
    }

    function init_action(){
        add_action( 'publish_book', [$this, 'published_social_platform'], 10, 2 );
        add_action( 'save_post_article', [$this, 'published_on_article_save'] );
    }

    function published_on_article_publish($ID, $post){
        $this->create_log($post);
    }
    
    function published_on_article_save() {
        $result = [];
        global $post;
        $result = $this->share_on_platforms($post);
        $this->create_log($result);
    }

    function share_on_platforms($post){

        $result = [];
        $twitter = new autoPubTW();
        $result['twitter'] = $twitter->do_publish($post);
        return $result;
    }

    function create_log($data){
        $logFile = fopen(YHM_SOCIAL_PATH.'log.txt', 'a+');
        fwrite($logFile, print_r($data, TRUE));
        $newline = PHP_EOL.time().PHP_EOL;
        fwrite($logFile, $newline);
        fclose($logFile);
        
    }

}


?>