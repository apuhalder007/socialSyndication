jQuery(document).ready(function () {
    jQuery(".scheduleDatetime").datepicker({
        dateFormat: 'yy-mm-dd',
        //numberOfMonths: 3
    });
    
    jQuery(".yhmSocial_publish_status").change(function(){
        var _this = jQuery(this);
        var _this_val = _this.val();
        if (_this_val == 'schedule'){
            _nextDateTime = _this.next(".scheduleDatetime");
            _nextDateTime.css("display", "inline-block");
            _nextDateTime.focus();
            //_nextDateTime.trigger('click');
            
        }else{
            _nextDateTime = _this.next(".scheduleDatetime");
            _nextDateTime.val('');
            _nextDateTime.css("display", "none");
            
        }
    });
});