<?php

class yhmArticleSocial_Meta_Box
{
    public static function add()
    {
        $screens = ['article'];
        foreach ($screens as $screen) {
            add_meta_box(
                'yhmSocial_Meta_id',          // Unique ID
                'Custom Meta Box Title', // Box title
                [self::class, 'html'],   // Content callback, must be of type callable
                $screen                  // Post type
            );
        }
    }
 
    public function save($post_id)
    {
        if(isset( $_POST['yhmSocial'])){
           
            foreach($_POST['yhmSocial'] as $key => $value){
               
                update_post_meta(
                    $post_id,
                    $key.'_publush_status',
                    $value['status']
                );

                update_post_meta(
                    $post_id,
                    $key.'_scheduleDatetime',
                    $value['scheduleDatetime']
                );
            }

        }
    }
 
    public function html($post)
    {
        $twitter_staus = get_post_meta($post->ID, 'yhmSocial_twitter_staus', true);

        $social_providers = ['twitter', 'facebook', 'linkedin'];
        ?>
        <div class="socialmeta_fields_wrapper">
            <?php foreach($social_providers as $provider){
               $status =  get_post_meta($post->ID, $provider.'_publush_status', true);
               $scheduleDatetime = get_post_meta($post->ID, $provider.'_scheduleDatetime', true);
               $scheduleDisplay = ($scheduleDatetime !=null || $scheduleDatetime != '') 
                                ? 'display:inline-block': 'display:none';
            ?>
            
            <div class="<?php echo $provider;?>-section">
                <label for="yhmSocial_<?php echo $provider;?>_status_field"><?php echo $provider;?> Status</label>
                <select name="yhmSocial[<?php echo $provider;?>][status]" id="yhmSocial_<?php echo $provider;?>_staus" class="yhmSocial_publish_status">
                    <option value="">Select Status</option>
                    <option value="yes" <?php selected($status, 'yes'); ?>>YES</option>
                    <option value="no" <?php selected($status, 'no'); ?>>NO</option>
                    <option value="schedule" <?php selected($status, 'schedule'); ?>>Schedule</option>
                </select>
                <input type="text" class="scheduleDatetime" 
                    name="yhmSocial[<?php echo $provider;?>][scheduleDatetime]" 
                    id="yhmSocial_<?php echo $provider;?>_scheduleDatetime" 
                    value="<?php echo $scheduleDatetime;?>"
                    style="<?php echo $scheduleDisplay;?>"
                    >
            </div>
            <hr/>
            <?php }?>    
            

        </div>
        <?php
    }

    // Register datepicker ui for properties
    function load_scripts(){
        global $post;
        if($post->post_type == 'article' && is_admin()) {
            wp_enqueue_script('jquery-ui-datepicker');  
            wp_enqueue_script('yhm-meta-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/yhm-meta-scripts.js'); 
        }
    }

    // Register ui styles for properties
    function load_styles(){
        global $post;
        if($post->post_type == 'article' && is_admin()) {
            wp_enqueue_style('jquery-ui','http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
            wp_enqueue_style('yhm-meta-styles',plugin_dir_url( __FILE__ ) . 'assets/css/yhm-meta-styles.css');
        }
    }

    function load_meta_hooks(){
        add_action('add_meta_boxes', [$this, 'add']);
        add_action('save_post', [$this, 'save']);
        add_action('admin_print_scripts', [$this,'load_scripts']);
        add_action('admin_print_styles', [$this,'load_styles']);
       
    }

    
}
 
